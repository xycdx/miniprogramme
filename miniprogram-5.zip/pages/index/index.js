Page({
  fabu(){
    wx.navigateTo({
      url: '../post/post',
    })
  }
})